package com.example

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class KnowledgeProcessingService : Service() {
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fileName = intent?.getStringExtra("FILE_NAME")
        val fileContent = intent?.getStringExtra("FILE_CONTENT")

        if (fileName != null && fileContent != null) {
            serviceScope.launch {
                processContent(fileName, fileContent)
                stopSelf(startId) // Stop service when done
            }
        } else {
            stopSelf(startId)
        }

        return START_NOT_STICKY
    }

    private fun processContent(baseFileName: String, text: String) {
        try {
            val entitiesList = mutableListOf<String>()

            // 1. Extract Emails
            val emailRegex = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}".toRegex()
            val emails = emailRegex.findAll(text).map { it.value }.toSet()
            if (emails.isNotEmpty()) entitiesList.add("Emails:\n- ${emails.joinToString("\n- ")}")

            // 2. Extract Phone numbers
            val phoneRegex = "(?:\\+?\\d{1,3}[- ]?)?\\(?\\d{3}\\)?[- ]?\\d{3}[- ]?\\d{4}".toRegex()
            val phones = phoneRegex.findAll(text).map { it.value }.toSet()
            if (phones.isNotEmpty()) entitiesList.add("Phone Numbers:\n- ${phones.joinToString("\n- ")}")

            // 3. Extract Dates
            val dateRegex = "\\b\\d{1,4}[-/]\\d{1,2}[-/]\\d{1,4}\\b".toRegex()
            val dates = dateRegex.findAll(text).map { it.value }.toSet()
            if (dates.isNotEmpty()) entitiesList.add("Dates detected:\n- ${dates.joinToString("\n- ")}")

            // 4. Simple Contextual Extraction (Bengali Keywords related to personal info)
            val banglaKeywords = listOf("নাম", "ঠিকানা", "বয়স", "পাসওয়ার্ড", "অ্যাকাউন্ট", "ইমেইল", "শখ", "লক্ষ্য", "জন্ম")
            val foundContext = mutableListOf<String>()
            
            // Clean up text and split to lines
            val lines = text.lines()
            for (line in lines) {
                val cleanLine = line.trim()
                if (cleanLine.isNotEmpty()) {
                    for (keyword in banglaKeywords) {
                        if (cleanLine.contains(keyword)) {
                            foundContext.add(cleanLine)
                            break // Prevent duplicate log of the same line
                        }
                    }
                }
            }
            if (foundContext.isNotEmpty()) {
                entitiesList.add("Key Bengali Context Info:\n- " + foundContext.joinToString("\n- "))
            }

            if (entitiesList.isNotEmpty()) {
                val entitySummary = "--- EXTRACTED ENTITIES FROM $baseFileName ---\n\n" + entitiesList.joinToString("\n\n")
                val extractedFileName = "extracted_entities_$baseFileName"
                
                ActivityLogManager.saveMemoryFile(this, extractedFileName, entitySummary)
                ActivityLogManager.logAction(this, "KnowledgeProcessor: Extracted entities from $baseFileName")
            } else {
                ActivityLogManager.logAction(this, "KnowledgeProcessor: No significant entities found in $baseFileName")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            ActivityLogManager.logAction(this, "KnowledgeProcessor Error: Failed to process $baseFileName")
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null // We don't need to support binding
    }
}
