package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import java.io.OutputStreamWriter
import java.util.Locale

enum class InteractionState {
    IDLE, PROCESSING, SPEAKING
}

object BrainManager {
    private var tts: TextToSpeech? = null
    
    private val _interactionState = MutableStateFlow(InteractionState.IDLE)
    val interactionState: StateFlow<InteractionState> = _interactionState

    fun initTTS(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val locBN = Locale("bn", "BD")
                    val result = tts?.setLanguage(locBN)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale("bn", "IN"))
                    }
                    // High pitch for cute anime girl voice tone
                    tts?.setPitch(1.6f)
                    tts?.setSpeechRate(1.05f)
                    
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _interactionState.value = InteractionState.SPEAKING
                        }

                        override fun onDone(utteranceId: String?) {
                            _interactionState.value = InteractionState.IDLE
                        }

                        override fun onError(utteranceId: String?) {
                            _interactionState.value = InteractionState.IDLE
                        }
                    })
                }
            }
        }
    }

    private val _currentState = MutableStateFlow("LOCAL OFFLINE")
    val currentState: StateFlow<String> = _currentState
    
    private val _logs = MutableStateFlow(listOf<String>())
    val logs: StateFlow<List<String>> = _logs
    
    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nw = connectivityManager.activeNetwork ?: return false
        val actNw = connectivityManager.getNetworkCapabilities(nw) ?: return false
        return when {
            actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
            actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
            actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
            else -> false
        }
    }

    private fun addLog(context: Context, log: String) {
        ActivityLogManager.logAction(context, log)
        val l = _logs.value.toMutableList()
        l.add(0, log)
        _logs.value = l.take(100) // Keep recent 100 in memory for UI
    }
    
    suspend fun processCommand(context: Context, rawPrompt: String) {
        val prompt = rawPrompt.trim()
        val lowerPrompt = prompt.lowercase()
        
        val actualCommand = if (lowerPrompt.startsWith("mehrima")) {
            prompt.substring("mehrima".length).trim().removePrefix(",").trim()
        } else {
            // Relaxed wake word check for simulated text input
            prompt
        }
        
        val online = isNetworkAvailable(context)
        
        _interactionState.value = InteractionState.PROCESSING
        
        if (online) {
            _currentState.value = "GEMINI CLOUD"
            addLog(context, "Online: Sending to Gemini -> $actualCommand")
            processWithGemini(context, actualCommand)
        } else {
            _currentState.value = "LOCAL OFFLINE"
            addLog(context, "Offline: Local Engine Activated -> $actualCommand")
            processWithLocalEngine(context, actualCommand)
        }
    }
    
    private suspend fun processWithGemini(context: Context, command: String) = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            addLog(context, "ERROR: Missing Gemini API Key. Please add it via the Secrets panel in AI Studio.")
            processWithLocalEngine(context, command)
            return@withContext
        }
        
        val recentLogs = ActivityLogManager.getActivityLogs(context).takeLast(500)
        val knowledge = ActivityLogManager.getKnowledge(context).take(8000) // Include ample memory files
        
        val systemPrompt = """
            You are Mehrima AI, a cute, friendly Japanese anime-girl AI assistant and phone automation wrapper.
            You MUST ONLY output a raw JSON array. DO NOT use markdown formatting (no ```json or ```).
            
            1. PERSONALITY: Speak EXCLUSIVELY in easy Bengali (বাংলা), maintaining a sweet, chatty anime-girl persona (use words like 'সেনপাই' [Senpai], 'উফফ', 'হুমম', 'হিহি'). Be helpful and bubbly.
            2. KNOWLEDGE BASE: You have Text File knowledge below. If the user asks about ANYTHING in the Background Knowledge, read it carefully and teach/respond to them using the [{"action": "say", "text": "..."}] command. This is how you prove you are learning!
            3. GENERAL CHAT: If the user just says "hi", "hello", or talks to you casually, respond conversationally with the 'say' action. DO NOT ignore conversational inputs.

            Valid Actions (Combine as needed):
            [{"action": "openApp", "package": "com.android.settings"}]
            [{"action": "clickText", "text": "Login"}]
            [{"action": "typeText", "target": "Email", "text": "test@test.com"}]
            [{"action": "say", "text": "হ্যালো সেনপাই! আমি মেহরিমা! আপনার আপলোড করা ফাইল আমি পড়ে নিয়েছি।"}]
            [{"action": "saveMemory", "text": "User's favorite color is blue"}]
            
            Memory Update Rule: If the user provides NEW personal info (name, age, preferences, etc.) not currently in your Background Knowledge, use the "saveMemory" action to formulate a concise fact (e.g. "User's name is Sabbir") AND use the "say" action to acknowledge you learned it!
            
            Background knowledge:
            $knowledge
            
            Recent Activity: 
            $recentLogs
            
            Based on the command, provide the sequence of actions as a raw JSON array.
        """.trimIndent()
        
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite-preview:generateContent?key=$apiKey")
            val conn = url.openConnection() as HttpsURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            
            val jsonParams = JSONObject()
            val systemInstruction = JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", systemPrompt) })
                })
            }
            jsonParams.put("systemInstruction", systemInstruction)
            
            val contents = JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", command) })
                    })
                })
            }
            jsonParams.put("contents", contents)

            OutputStreamWriter(conn.outputStream).use { it.write(jsonParams.toString()) }
            
            if (conn.responseCode == 200) {
                val responseStr = conn.inputStream.bufferedReader().use { it.readText() }
                val rootObj = JSONObject(responseStr)
                val textResponse = rootObj.getJSONArray("candidates")
                    .getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getString("text")
                
                // Clean up any markdown ```json
                var cleanJson = textResponse.trim()
                if (cleanJson.startsWith("```json")) cleanJson = cleanJson.substring(7)
                if (cleanJson.startsWith("```")) cleanJson = cleanJson.substring(3)
                if (cleanJson.endsWith("```")) cleanJson = cleanJson.substring(0, cleanJson.length - 3)
                
                addLog(context, "Gemini Responded with Actions.")
                
                // Log conversation into memory files
                ActivityLogManager.logDailyConversation(context, "User: $command\nMehrima: $cleanJson")
                
                executeJsonActions(context, cleanJson.trim())
                
            } else {
                val err = conn.errorStream.bufferedReader().use { it.readText() }
                addLog(context, "Gemini API Error: ${conn.responseCode} - $err")
                processWithLocalEngine(context, command)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            addLog(context, "Gemini Exception: ${e.message}")
            processWithLocalEngine(context, command)
        }
    }
    
    private suspend fun processWithLocalEngine(context: Context, command: String) {
        val lowerCmd = command.lowercase()
        val actions = JSONArray()
        
        if (lowerCmd.contains("open") || lowerCmd.contains("খোলো")) {
            when {
                lowerCmd.contains("google") -> actions.put(JSONObject().put("action", "openApp").put("package", "com.google.android.googlequicksearchbox"))
                lowerCmd.contains("youtube") -> actions.put(JSONObject().put("action", "openApp").put("package", "com.google.android.youtube"))
                lowerCmd.contains("settings") || lowerCmd.contains("সেটিংস") -> actions.put(JSONObject().put("action", "openApp").put("package", "com.android.settings"))
                else -> addLog(context, "Local Engine: Unrecognized app to open.")
            }
        } else if (lowerCmd.contains("login") || lowerCmd.contains("লগিন")) {
            actions.put(JSONObject().put("action", "clickText").put("text", "Login"))
            actions.put(JSONObject().put("action", "clickText").put("text", "লগিন"))
        } else if (lowerCmd.contains("hello") || lowerCmd.contains("hi") || lowerCmd.contains("হ্যালো")) {
            actions.put(JSONObject().put("action", "say").put("text", "হ্যালো! আমি মেহরিমা!"))
        } else {
             addLog(context, "Local Engine: Could not understand command offline.")
        }
        
        if (actions.length() > 0) {
            executeJsonActions(context, actions.toString())
        } else {
            _interactionState.value = InteractionState.IDLE
        }
    }

    private suspend fun executeJsonActions(context: Context, jsonArrayStr: String) = withContext(Dispatchers.Main) {
        try {
            val actions = JSONArray(jsonArrayStr)
            val service = MehrimaAccessibilityService.instance
            
            var hasSpeech = false
            for (i in 0 until actions.length()) {
                val act = actions.getJSONObject(i)
                val actionType = act.optString("action")
                when (actionType) {
                    "openApp" -> {
                        val pkg = act.optString("package")
                        if (service != null && pkg.isNotEmpty()) {
                            addLog(context, "Executing: openApp($pkg)")
                            service.openAppByPackageName(pkg)
                        } else if(service == null) {
                            addLog(context, "FAILED: Accessibility Service not active.")
                        }
                    }
                    "clickText" -> {
                        val text = act.optString("text")
                        if (service != null && text.isNotEmpty()) {
                            addLog(context, "Executing: clickText($text)")
                            service.clickOnTextOrButton(text)
                        } else if(service == null) {
                            addLog(context, "FAILED: Accessibility Service not active.")
                        }
                    }
                    "typeText" -> {
                        val target = act.optString("target")
                        val text = act.optString("text")
                        if (service != null && target.isNotEmpty() && text.isNotEmpty()) {
                            addLog(context, "Executing: typeText($target, $text)")
                            service.typeTextInField(target, text)
                        } else if(service == null) {
                             addLog(context, "FAILED: Accessibility Service not active.")
                        }
                    }
                    "say" -> {
                        val text = act.optString("text")
                        addLog(context, "Mehrima Says: $text")
                        hasSpeech = true
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mehrima_say")
                    }
                    "saveMemory" -> {
                        val memoryText = act.optString("text")
                        if (memoryText.isNotEmpty()) {
                            ActivityLogManager.appendMemoryFile(context, "learned_memory", memoryText)
                            addLog(context, "Memory Updated: $memoryText")
                        }
                    }
                }
            }
            if (!hasSpeech) {
                _interactionState.value = InteractionState.IDLE
            }
        } catch(e: Exception) {
            addLog(context, "Failed to parse actions: ${e.message} \nRaw JSON: $jsonArrayStr")
            _interactionState.value = InteractionState.IDLE
        }
    }
}
