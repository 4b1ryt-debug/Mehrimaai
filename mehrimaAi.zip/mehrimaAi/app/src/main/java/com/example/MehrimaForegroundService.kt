package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MehrimaForegroundService : Service() {

    private val CHANNEL_ID = "MehrimaServiceChannel"
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var speechRecognizer: SpeechRecognizer? = null
    private var vadHandler: Handler? = null
    private var vadRunnable: Runnable? = null
    private val VAD_TIMEOUT_MS = 1500L
    private var isListeningLoopActive = false
    private var currentSpokenText = ""

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        vadHandler = Handler(Looper.getMainLooper())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Mehrima AI")
            .setContentText("Listening... (VAD Active)")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
            
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, notification)
            }
        } catch(e: Exception) {
           e.printStackTrace()
        }

        serviceScope.launch {
            ActivityLogManager.logAction(this@MehrimaForegroundService, "Background VAD service started.")
        }

        isListeningLoopActive = true
        initSpeechRecognizer()

        return START_STICKY
    }

    private fun initSpeechRecognizer() {
        Handler(Looper.getMainLooper()).post {
            if (speechRecognizer != null) {
                speechRecognizer?.destroy()
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {
                    currentSpokenText = ""
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                
                override fun onError(error: Int) {
                    if (isListeningLoopActive) {
                        // Restart after a small delay on error to avoid looping madly
                        Handler(Looper.getMainLooper()).postDelayed({
                            restartListening()
                        }, 500)
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        currentSpokenText = matches[0]
                        processSpokenText()
                    } else if (isListeningLoopActive) {
                        restartListening()
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        currentSpokenText = matches[0]
                        resetVadTimer()
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            
            restartListening()
        }
    }

    private fun restartListening() {
        if (!isListeningLoopActive) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun resetVadTimer() {
        vadRunnable?.let { vadHandler?.removeCallbacks(it) }
        vadRunnable = Runnable {
            speechRecognizer?.stopListening()
            processSpokenText()
        }
        vadHandler?.postDelayed(vadRunnable!!, VAD_TIMEOUT_MS)
    }

    private fun processSpokenText() {
        vadHandler?.removeCallbacksAndMessages(null)
        val text = currentSpokenText.trim()
        currentSpokenText = ""
        
        if (text.isNotEmpty()) {
            ActivityLogManager.logAction(this, "Heard: $text")
            serviceScope.launch {
                BrainManager.processCommand(this@MehrimaForegroundService, text)
                // Resume listening after command logic resolves
                Handler(Looper.getMainLooper()).post {
                    restartListening()
                }
            }
        } else {
            if (isListeningLoopActive) restartListening()
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null // Not bound
    }
    
    override fun onDestroy() {
        super.onDestroy()
        isListeningLoopActive = false
        vadHandler?.removeCallbacksAndMessages(null)
        Handler(Looper.getMainLooper()).post {
            speechRecognizer?.destroy()
            speechRecognizer = null
        }
        ActivityLogManager.logAction(this, "Background VAD service stopped.")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Mehrima Background Listener",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }
}
