package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MehrimaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ActivityLogManager.logAction(this, "Accessibility Service Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Keeps the connection alive, but we poll defensively
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        ActivityLogManager.logAction(this, "Accessibility Service Disconnected")
        return super.onUnbind(intent)
    }

    fun openAppByPackageName(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            ActivityLogManager.logAction(this, "Launched app: $packageName")
            return true
        }
        ActivityLogManager.logAction(this, "Failed to launch app: $packageName")
        return false
    }

    fun clickOnTextOrButton(targetText: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val foundNodes = rootNode.findAccessibilityNodeInfosByText(targetText)
        for (node in foundNodes) {
            if (node.isClickable || node.isCheckable) {
                val success = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (success) {
                    ActivityLogManager.logAction(this, "Clicked on: $targetText")
                    return true
                }
            } else {
                // Try parent nodes if the text itself isn't clickable
                var parent = node.parent
                val maxDepth = 5
                var currentDepth = 0
                while (parent != null && currentDepth < maxDepth) {
                    if (parent.isClickable) {
                        val success = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        if (success) {
                            ActivityLogManager.logAction(this, "Clicked parent of: $targetText")
                            return true
                        }
                    }
                    parent = parent.parent
                    currentDepth++
                }

                // If no clickable parent, gesture click based on bounds
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                if(!bounds.isEmpty) {
                    val x = bounds.centerX()
                    val y = bounds.centerY()
                    val path = Path()
                    path.moveTo(x.toFloat(), y.toFloat())
                    val gestureBuilder = GestureDescription.Builder()
                    gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
                    val gestureDispatched = dispatchGesture(gestureBuilder.build(), null, null)
                    if(gestureDispatched) {
                         ActivityLogManager.logAction(this, "Gesture clicked on: $targetText")
                         return true
                    }
                }
            }
        }
        ActivityLogManager.logAction(this, "Failed to click on: $targetText")
        return false
    }

    fun typeTextInField(targetElementText: String, textToType: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val foundNodes = rootNode.findAccessibilityNodeInfosByText(targetElementText)
        for (node in foundNodes) {
            if (node.isEditable) {
                val arguments = Bundle()
                arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
                val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
                if (success) {
                    ActivityLogManager.logAction(this, "Typed text in: $targetElementText")
                    return true
                }
            }
        }
        ActivityLogManager.logAction(this, "Failed to find editable field for: $targetElementText")
        return false
    }

    companion object {
        var instance: MehrimaAccessibilityService? = null
            private set
    }
}
