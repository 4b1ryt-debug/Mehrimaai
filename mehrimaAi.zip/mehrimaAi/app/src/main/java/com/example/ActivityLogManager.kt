package com.example

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ActivityLogManager {
    private const val LOG_FILE_NAME = "mehrima_activity_log.txt"
    private const val MEMORY_DIR_NAME = "mehrima_memory"

    private fun getMemoryDir(context: Context): File {
        val dir = File(context.filesDir, MEMORY_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Appends a log entry to the activity log file with a timestamp.
     */
    fun logAction(context: Context, action: String) {
        try {
            val file = File(context.filesDir, LOG_FILE_NAME)
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val logEntry = "[$timestamp] $action\n"
            file.appendText(logEntry)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Saves daily conversations into a memory file so the user can read/edit/delete it.
     */
    fun logDailyConversation(context: Context, chat: String) {
        try {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val fileName = "chat_$dateStr.txt"
            val file = File(getMemoryDir(context), fileName)
            file.appendText("$chat\n\n")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Appends content to a specific memory file, creating it if it doesn't exist.
     */
    fun appendMemoryFile(context: Context, fileName: String, content: String) {
        try {
            var name = fileName
            if (!name.endsWith(".txt")) name += ".txt"
            val file = File(getMemoryDir(context), name)
            file.appendText("$content\n")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Returns the entire activity log history as a String.
     */
    fun getActivityLogs(context: Context): String {
        return try {
            val file = File(context.filesDir, LOG_FILE_NAME)
            if (file.exists()) file.readText() else "No activity logs."
        } catch (e: Exception) {
            "Error reading logs: ${e.message}"
        }
    }
    
    /**
     * Reads all knowledge from the memory directory.
     */
    fun getKnowledge(context: Context): String {
        val memoryDir = getMemoryDir(context)
        val files = memoryDir.listFiles { _, name -> name.endsWith(".txt") } ?: return ""
        val builder = java.lang.StringBuilder()
        for (file in files) {
            try {
                builder.append("---[${file.name}]---\n")
                // Take up to 8000 chars from the start of the file to ensure context is retained
                val text = file.readText()
                builder.append(if (text.length > 8000) text.take(8000) else text)
                builder.append("\n\n")
            } catch (e: Exception) { e.printStackTrace() }
        }
        return builder.toString()
    }

    /**
     * Lists all knowledge files.
     */
    fun listMemoryFiles(context: Context): List<File> {
        return getMemoryDir(context).listFiles { _, name -> name.endsWith(".txt") }?.toList() ?: emptyList()
    }

    /**
     * Reads a specific memory file.
     */
    fun readMemoryFile(file: File): String {
        return try { file.readText() } catch (e: Exception) { "" }
    }

    /**
     * Saves or overwrites a memory file.
     */
    fun saveMemoryFile(context: Context, fileName: String, content: String) {
        try {
            var name = fileName
            if (!name.endsWith(".txt")) name += ".txt"
            val file = File(getMemoryDir(context), name)
            file.writeText(content)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Deletes a memory file.
     */
    fun deleteMemoryFile(file: File) {
        try {
            if (file.exists()) file.delete()
        } catch (e: Exception) { e.printStackTrace() }
    }

    /**
     * Copies a user picked file to the memory directory and triggers entity extraction.
     */
    fun importTxtFile(context: Context, uri: Uri) {
        try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val text = inputStream?.bufferedReader()?.use { it.readText() } ?: return
            
            // Generate file name based on time
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val importedFileName = "imported_knowledge_$timestamp.txt"
            saveMemoryFile(context, importedFileName, text)
            
            // Trigger Entity Extraction in background service
            val intent = android.content.Intent(context, KnowledgeProcessingService::class.java).apply {
                putExtra("FILE_NAME", importedFileName)
                putExtra("FILE_CONTENT", text)
            }
            context.startService(intent)
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun clearLogs(context: Context) {
        try {
            val file = File(context.filesDir, LOG_FILE_NAME)
            if (file.exists()) file.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
