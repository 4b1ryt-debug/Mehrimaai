package com.example

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.animation.core.*
import kotlinx.coroutines.launch

@Composable
fun AnimeFaceVisualizer(interactionState: InteractionState) {
    val infiniteTransition = rememberInfiniteTransition(label = "face_anim")
    
    // Idle blinking
    val blink by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 4000
                1f at 0
                1f at 3700
                0.1f at 3800
                1f at 3900
                1f at 4000
            },
            repeatMode = RepeatMode.Restart
        ), label = "blink"
    )

    // For speaking, animate mouth up and down
    val speakMouth by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "speakMouth"
    )
    
    val isSpeaking = interactionState == InteractionState.SPEAKING
    val isProcessing = interactionState == InteractionState.PROCESSING
    
    val actualMouthHeight = if (isSpeaking) 6.dp + (18.dp * speakMouth) else 4.dp
    
    // Processing: swirl eyes or move them slightly
    val eyeOffsetX by animateDpAsState(
        targetValue = if (isProcessing) 8.dp else 0.dp,
        animationSpec = infiniteRepeatable(tween(400), repeatMode = RepeatMode.Reverse), label = "eyeOffset"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        // Glow effect based on state
        val glowColor = when (interactionState) {
            InteractionState.SPEAKING -> Color(0xFFc084fc)
            InteractionState.PROCESSING -> Color(0xFFf97316)
            else -> Color(0xFF06b6d4)
        }
        
        Box(Modifier.size(250.dp).blur(48.dp).background(glowColor.copy(alpha = 0.15f), CircleShape))

        // Face Container
        Box(
            modifier = Modifier
                .size(160.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF0891b2).copy(alpha = 0.2f), Color(0xFF9333ea).copy(alpha = 0.2f))), CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.1f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Eyes
            Row(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(x = if (isProcessing) eyeOffsetX else 0.dp, y = (-16).dp),
                horizontalArrangement = Arrangement.spacedBy(32.dp)
            ) {
                // Left Eye
                Box(
                    modifier = Modifier
                        .width(20.dp).height(32.dp * blink)
                        .background(Color(0xFF22D3EE), RoundedCornerShape(50))
                        .shadow(8.dp, spotColor = Color(0xFF22D3EE))
                )
                // Right Eye
                Box(
                    modifier = Modifier
                        .width(20.dp).height(32.dp * blink)
                        .background(Color(0xFF22D3EE), RoundedCornerShape(50))
                        .shadow(8.dp, spotColor = Color(0xFF22D3EE))
                )
            }
            
            // Cheeks (blush) when speaking
            if (isSpeaking) {
                Row(
                    modifier = Modifier.align(Alignment.Center).offset(y = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(56.dp)
                ) {
                    Box(Modifier.size(16.dp, 8.dp).background(Color(0xFFec4899).copy(alpha=0.4f), RoundedCornerShape(50)).blur(4.dp))
                    Box(Modifier.size(16.dp, 8.dp).background(Color(0xFFec4899).copy(alpha=0.4f), RoundedCornerShape(50)).blur(4.dp))
                }
            }

            // Mouth
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 28.dp)
                    .width(if (isSpeaking) 24.dp else 16.dp)
                    .height(actualMouthHeight)
                    .background(if (isSpeaking) Color(0xFFf472b6) else Color(0xFF22D3EE).copy(alpha=0.6f), RoundedCornerShape(50))
            )
        }
    }
}

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        BrainManager.initTTS(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO))
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        MehrimaDashboard(this@MainActivity)
                    }
                }
            }
        }
    }
}

@Composable
fun MehrimaDashboard(context: Context) {
    val coroutineScope = rememberCoroutineScope()
    val logs by BrainManager.logs.collectAsState()
    val currentState by BrainManager.currentState.collectAsState()
    var inputText by remember { mutableStateOf("") }
    
    var trigger by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while(true) {
            kotlinx.coroutines.delay(1000)
            trigger++
        }
    }
    
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
    val isAccessibilityEnabled = enabledServices.any { it.resolveInfo.serviceInfo.name == MehrimaAccessibilityService::class.java.name }

    var currentScreen by remember { mutableStateOf("Dashboard") }

    if (currentScreen == "FileManager") {
        FileManagerScreen(
            context = context,
            onBack = { currentScreen = "Dashboard" }
        )
        return
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .verticalScroll(scrollState)
    ) {
        val interactionState by BrainManager.interactionState.collectAsState()
        
        // Header Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Mehrima AI", color = Color(0xFF22D3EE), fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)
                Text("Production v1.0.4", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                val isOnline = currentState == "GEMINI CLOUD"
                val stateBg = if (isOnline) Color(0xFF06b6d4).copy(alpha = 0.1f) else Color(0xFFf97316).copy(alpha = 0.1f)
                val stateBorder = if (isOnline) Color(0xFF06b6d4).copy(alpha = 0.3f) else Color(0xFFf97316).copy(alpha = 0.3f)
                val stateText = if (isOnline) Color(0xFF22D3EE) else Color(0xFFfdba74)
                
                Box(
                    modifier = Modifier
                        .background(stateBg, RoundedCornerShape(4.dp))
                        .border(1.dp, stateBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(currentState.uppercase(), color = stateText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("Latency: ${if(isOnline) "42ms" else "0ms"}", color = Color.White.copy(alpha = 0.3f), fontSize = 9.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        // Main AI Visualizer Area
        AnimeFaceVisualizer(interactionState = interactionState)

        // Status Text
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            val statusColor = when(interactionState) {
                InteractionState.SPEAKING -> Color(0xFFc084fc)
                InteractionState.PROCESSING -> Color(0xFFf97316)
                else -> Color.White.copy(alpha=0.6f)
            }
            val statusLabel = when(interactionState) {
                InteractionState.SPEAKING -> "Speaking..."
                InteractionState.PROCESSING -> "Thinking..."
                else -> "\"Waiting for wake-word...\""
            }
            Text(statusLabel, color = statusColor, fontSize = 14.sp, fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic)
            Row(modifier = Modifier.padding(top = 4.dp)) {
                Text(if(interactionState == InteractionState.IDLE) "Listening: " else "State: ", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Light)
                Text(if(interactionState == InteractionState.IDLE) "Mehrima..." else interactionState.name, color = Color(0xFF22D3EE), fontSize = 24.sp, fontWeight = FontWeight.Light)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Interactivity Area
        Column(modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!isAccessibilityEnabled) {
                Button(
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626).copy(alpha = 0.1f), contentColor = Color(0xFFF87171)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFDC2626).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                ) {
                    Text("Enable Accessibility Service", fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = {
                    val intent = Intent(context, MehrimaForegroundService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(intent)
                    } else {
                        context.startService(intent)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.05f), contentColor = Color.White.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
            ) {
                Text("Start Background Listener", fontWeight = FontWeight.SemiBold)
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Simulate Command...", color = Color.White.copy(alpha = 0.3f)) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF22D3EE),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color(0xFF22D3EE)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Button(
                    onClick = {
                        coroutineScope.launch {
                            BrainManager.processCommand(context, inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier.height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06b6d4).copy(alpha = 0.2f), contentColor = Color(0xFF22D3EE)),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text("Send")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Activity Log Console
        Box(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(6.dp).background(Color(0xFF22C55E), CircleShape))
                        Text("ACTIVITY LOG", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                    Text("RAM: 48MB", color = Color(0xFF22D3EE), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                LazyColumn(
                    modifier = Modifier.height(120.dp).fillMaxWidth()
                ) {
                    items(logs) { log ->
                        Text(
                            text = "> $log",
                            color = if (log.contains("Gemini", true) || log.contains("Mehrima Says", true)) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.6f),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Footer / Tools Section
        Button(
            onClick = { currentScreen = "FileManager" },
            modifier = Modifier.padding(horizontal = 24.dp).fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22D3EE).copy(alpha = 0.1f), contentColor = Color(0xFF22D3EE)),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22D3EE).copy(alpha = 0.3f))
        ) {
            Text("Open Memory & Knowledge Manager", fontWeight = FontWeight.Bold)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun FileManagerScreen(context: Context, onBack: () -> Unit) {
    var refreshTrigger by remember { mutableStateOf(0) }
    var memoryFiles by remember { mutableStateOf(emptyList<java.io.File>()) }
    
    var selectedFileToEdit by remember { mutableStateOf<java.io.File?>(null) }
    var editFileContent by remember { mutableStateOf("") }
    
    // For creating new files
    var creatingNewFile by remember { mutableStateOf(false) }
    var newFileName by remember { mutableStateOf("") }

    LaunchedEffect(refreshTrigger) {
        memoryFiles = ActivityLogManager.listMemoryFiles(context)
    }
    
    val filePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            ActivityLogManager.importTxtFile(context, uri)
            refreshTrigger++
        }
    }
    
    if (selectedFileToEdit != null || creatingNewFile) {
        val title = if (creatingNewFile) "Create New Memory File" else "Edit File: ${selectedFileToEdit?.name}"
        AlertDialog(
            onDismissRequest = { 
                selectedFileToEdit = null 
                creatingNewFile = false 
            },
            title = { Text(title, color = Color(0xFF22D3EE), fontSize = 16.sp) },
            text = {
                Column {
                    if (creatingNewFile) {
                        OutlinedTextField(
                            value = newFileName,
                            onValueChange = { newFileName = it },
                            label = { Text("File Name (without .txt)", color = Color.White.copy(alpha=0.5f)) },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }
                    OutlinedTextField(
                        value = editFileContent,
                        onValueChange = { editFileContent = it },
                        modifier = Modifier.fillMaxWidth().height(200.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        placeholder = { Text("Write something for Mehrima to learn...", color = Color.White.copy(alpha=0.3f)) }
                    )
                }
            },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22D3EE), contentColor = Color.Black),
                    onClick = {
                    if (creatingNewFile) {
                        ActivityLogManager.saveMemoryFile(context, newFileName, editFileContent)
                    } else {
                        selectedFileToEdit?.let { file ->
                            ActivityLogManager.saveMemoryFile(context, file.name, editFileContent)
                        }
                    }
                    selectedFileToEdit = null
                    creatingNewFile = false
                    refreshTrigger++
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White),
                    onClick = { 
                        selectedFileToEdit = null
                        creatingNewFile = false 
                    }
                ) {
                    Text("Cancel")
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF050505)).padding(16.dp)) {
        // App Bar
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp, top = 8.dp)) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f), contentColor = Color.White),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Text("<")
            }
            Spacer(Modifier.width(16.dp))
            Text("Knowledge Base Manager", color = Color(0xFF22D3EE), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        // Actions
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { filePickerLauncher.launch("text/plain") },
                modifier = Modifier.weight(1f).height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06b6d4).copy(alpha=0.2f), contentColor = Color(0xFF22D3EE)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Upload .txt File")
            }
            Button(
                onClick = {
                    newFileName = ""
                    editFileContent = ""
                    creatingNewFile = true
                },
                modifier = Modifier.weight(1f).height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333ea).copy(alpha=0.2f), contentColor = Color(0xFFc084fc)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Create New File")
            }
        }

        // List
        Text("MEMORY FILES DIRECTORY", color = Color.White.copy(alpha=0.4f), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 12.dp))
        
        if (memoryFiles.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("No memory files found. Mehrima is starting fresh!", color = Color.White.copy(alpha=0.3f), fontStyle = FontStyle.Italic)
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(memoryFiles) { file ->
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha=0.05f), RoundedCornerShape(12.dp)).border(1.dp, Color.White.copy(alpha=0.1f), RoundedCornerShape(12.dp)).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(file.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("${file.length() / 1024} KB", color = Color.White.copy(alpha=0.5f), fontSize = 10.sp)
                        }
                        
                        Button(
                            onClick = {
                                editFileContent = ActivityLogManager.readMemoryFile(file)
                                creatingNewFile = false
                                selectedFileToEdit = file
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06b6d4).copy(alpha=0.15f), contentColor = Color(0xFF22D3EE)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Edit", fontSize = 12.sp)
                        }
                        
                        Spacer(Modifier.width(8.dp))
                        
                        Button(
                            onClick = {
                                ActivityLogManager.deleteMemoryFile(file)
                                refreshTrigger++
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626).copy(alpha=0.15f), contentColor = Color(0xFFF87171)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Del", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

